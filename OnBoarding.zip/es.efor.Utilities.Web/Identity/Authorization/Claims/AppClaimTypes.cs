﻿using System;
using System.Collections.Generic;
using System.Text;

namespace es.efor.Utilities.Web.Identity.Authorization.Claims
{
    public static class AppClaimTypes
    {
        public const string ClaimUpdateDatetime = "app-update-claim-datetime";
    }
}
