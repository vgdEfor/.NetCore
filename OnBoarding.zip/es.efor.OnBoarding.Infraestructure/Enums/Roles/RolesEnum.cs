﻿using System;
using System.Collections.Generic;
using System.Text;

namespace es.efor.OnBoarding.Infraestructure.Enums.Roles
{
    public enum RolesEnum
    {
        SuperAdmin = 1,
        Admin = 2,
        Employee = 3
    }
}
