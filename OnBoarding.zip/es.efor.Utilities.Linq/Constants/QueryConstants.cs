﻿using System;
using System.Collections.Generic;
using System.Text;

namespace es.efor.Utilities.Linq.Constants
{
    public static class QueryConstants
    {
        public const string ORDER_ASC = "asc";
        public const string ORDER_DESC = "desc";
    }
}
