﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace es.efor.Utilities.Linq.Models.Sorts
{
    public enum SortOperator
    {
        [Description("asc")] Ascending   = 0,
        [Description("des")] Descending  = 1,
    }
}
