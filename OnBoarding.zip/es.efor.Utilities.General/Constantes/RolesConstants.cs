﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace es.efor.Utilities.General.Constantes
{
    public static class RolesConstants
    {
        public const string PLANIFICACION = "Planificacion";
        public const string TECNICO = "Tecnico";
        public const string RESPONSABLE = "Responsable Planificar";
        public const string GESTOR = "Gestor Planificacion";
    }
}
