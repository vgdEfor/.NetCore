﻿# Ejercicio 1
El objetivo del primer ejercicio es realizar una **gestión de empresas** con las funcionalidades básicas 
de **obtención, listado, creación y eliminación**. Además, habrá que modificar la gestión de usuarios 
para incluir la empresa asociada a cada usuario.

# Ejercicio 2
El objetivo del segundo ejercicio es añadir el campo **responsable** a las empresas. El responsable 
deberá ser uno de los usuarios de la base de datos y **tendrá que pertenecer a la misma empresa a la 
cual queremos que sea responsable**.

Habrá que crear una nueva solicitud en el *gateway* para obtener el listado de usuarios y su responsable.